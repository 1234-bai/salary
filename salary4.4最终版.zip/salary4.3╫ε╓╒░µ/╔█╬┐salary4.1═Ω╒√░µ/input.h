#ifndef INPUT_H_INCLUDED
#define INPUT_H_INCLUDED

char input_char();

void input_stringnumber(char * m);

int string_to_number();

int scan_id(char a[]);

int input_id();

#endif // INPUT_H_INCLUDED
